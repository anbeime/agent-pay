# Rebel in Paradise AI Hackathon 参赛项目

## 🎯 赛事简介

**Rebel in Paradise AI Hackathon** 是由 OpenBuild 和 Monad 联合主办的 AI 黑客马拉松，聚焦 AI 与区块链的结合创新。

- **官网**: https://rebel.openbuild.xyz/
- **时间**: 2026年1月19日 - 2月28日
- **总奖金**: $40,000 USD

## 🚀 三大赛道

### 1. Agent-native Payments
基于AI Agent的支付解决方案

### 2. Intelligent Markets
智能市场解决方案

### 3. Agent-powered Apps
由AI Agent驱动的创新应用

## 📁 项目结构

```
rebel/
├── skills-config.yaml      # 技能配置文件
├── project.md              # 项目说明文档
├── CLAUDE.md              # 自动化开发指导
├── 项目启动指南.md         # 快速启动指南
├── task-status.json       # 任务状态跟踪
├── progress.txt           # 开发进度记录
├── README.md              # 本文件
├── output/                # 输出目录
│   ├── docs/             # 文档输出
│   ├── ppt/              # PPT输出
│   ├── code/             # 代码文件
│   └── assets/           # 资源文件
└── scripts/              # 脚本文件
```

## 🛠️ 快速开始

### 全自动开发模式

发送以下指令给AI助手：

```markdown
请为"Rebel in Paradise AI Hackathon"进行全自动开发。

操作要求：
1. 读取 skills-config.yaml 了解项目配置
2. 读取 task-status.json 了解当前任务状态
3. 按照任务清单持续开发，无需等待确认
4. 所有输出保存到 output/ 目录
5. 记录进度到 progress.txt
6. 直到所有任务完成或遇到无法解决的问题

开始执行。
```

### 分步开发

参考 `项目启动指南.md` 进行分步开发。

## 📅 重要日期

| 日期 | 事件 |
|-----|------|
| 2026-01-19 | 赛事开始 |
| 2026-01-31 | 北京黑客营 |
| 2026-02-07 | 深圳黑客营 |
| 2026-02-15 | 报名截止 |
| 2026-02-28 | 作品提交截止 |

## 💰 奖金设置

| 奖项 | 数量 | 金额 |
|-----|------|------|
| Grand Prize | 1 | $5,000 |
| 1st Place | 3 | $3,000 × 3 |
| 2nd Place | 3 | $2,000 × 3 |

## 🔗 资源链接

- **赛事官网**: https://rebel.openbuild.xyz/
- **报名链接**: https://mojo.devnads.com/events/10
- **Monad文档**: https://docs.monad.xyz/

## 📄 文档

- [项目方案](output/docs/项目方案_Rebel_20260217.docx)
- [技术文档](output/docs/技术文档_Rebel_20260217.docx)
- [路演PPT](output/ppt/路演PPT_Rebel_20260217.pptx)

---

*最后更新: 2026-02-17*